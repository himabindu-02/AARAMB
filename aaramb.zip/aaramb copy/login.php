<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link rel="stylesheet" href="stylec.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    <style>*{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family:'Times New Roman', Times, serif;
    }
    body{
        background:url(assets/imgs/rbg.jpg) no-repeat;
        background-position: center;
        background-size: cover;
        min-height: 100vh;
        width: 100%;
    }
    .container{
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }
    .form-box{
        position: relative;
        width: 400px;
        height: 550px;
        border: transparent;
        border-radius: 20px;
        backdrop-filter: blur(15px);
        justify-content: center;
        align-items: center;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .form-box h2{
        color:#879868;
        text-align: center;
        font-size: 32px;
    }
    .form-box .input-box{
        position: relative;
        margin: 30px 0;
        width: 310px;
        border-bottom: 2px solid white;
    }
    .form-box .input-box input{
        width: 100%;
        height: 45px;
        background: transparent;
        border: none;
        outline: none;
        padding: 0 20px 0 5px;
        color:rgb(0, 0, 0);
        font-size: 20px;
    }
    .input-box input::placeholder{
        color:#310303;
    }
    .btn{
        color:white;
        background: #879868;
        width: 100%;
        height: 50px;
        outline: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        box-shadow: 3px 0 10px rgba(0, 0, 0,.5);
    }
    .group{
        color:white;
        position: relative;
        top: 10px;
        text-decoration: none;
        font-weight: 500;
    }
    .group a:focus{
        text-decoration: underline;
    }
    #result{
        color: red;
        font-weight: 600;
        position: relative;
        top: 25px;
    }
    .popup{
        width: 300px;
        background-color: rgb(255, 255, 255);
        border-radius: 5px;
        position: absolute;
        top: 0;
        left: 50%;
        transform: translate(-50%, -50%) scale(0);
        transition: transform .4s , top .4s;
        visibility: hidden;
        text-align: center;
        padding: 0 70px 100px;
        height: 250px;
        color: black;
    }
    .popup ion-icon{
        color: #00ff00;
        font-size: 50px;
    }
    .popup button{
        width: 50%;
        background: rgba(2, 224, 80, 0.744);
        padding: 5px 0;
        margin-top: 50px;
        border: none;
        outline: none;
        font-size: 20px;
        color: rgb(1, 12, 68);
        border-radius: 5px;
        cursor: pointer;
        box-shadow:0 0 2px rgba(0, 0, 0, .1);
    }
    .popup a{
        color:white;
        text-decoration: none;
        font-weight: 600;
        letter-spacing: 2px;
    }
    .open-slide{
        top: 50%;
        transform: translate(-50%, -50%) scale(1);
        visibility: visible;
    } 
    .wrapper .remember-forgot{
    display: flex;
    justify-content: space-between;
    font-size: 14.5px;
    margin: -15px 0 15px;
}
.remember-forgot label input{
    accent-color: #1a0665;
    margin-right: 3px;
}
.remember-forgot a{
    color:#030e5e;
    text-decoration: none;
}
.remember-forgot a:hover{
    text-decoration: underline;
}
.register-link p a{
    color:#160347;
    text-decoration: none;
    font-weight: 600;
}
.register-link p a:hover{
    text-decoration: underline;
}
    </style>
</head>
<body>
    <div class="container">
        <div class="form-box">
            <form action="loginconc.php" method="post">
                <h2>LOGIN</h2>
                <p id="result"></p>
                <div class="input-box">
                    <input type="text" name="Email" placeholder="Your Email" required>
                </div>
                <div class="input-box">
                    <input type="text" name="Password" placeholder="Password" required>
                    <i class='bx bxs-lock-alt'></i></div>
                <div class="remember-forgot">
                    <label><input type="checkbox">Remember Me</label>
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  <a href="#">Forgot Password?</a>
                </div>
               <br>
                <div class="button">
                <button type="submit" name="submit"  value="submit" class="btn" >Login</button>
                <br>
                <br>
  <div class="register-link">
      <p>Don't have an account? <a href="reg.php">Register</a></p>
                </div>
            </form>
        </div>
        <!-- Popup div -->
        <div id="popup" class="popup" style="display:none;">
            <ion-icon name="checkmark-circle-outline"></ion-icon>
            <h2>Thank you!</h2>
            <p>Your Registration is Successful.</p>
            <a href="index.php"><button>OK</button></a>
        </div>
    </div>
</body>
</html>
