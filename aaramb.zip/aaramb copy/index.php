<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta name="OVER OVER VIEW port" content="width=device-width", initial-scale="1.0">
        <title>AARAMBH</title>
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    </head>
    <style>
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Open Sans", sans-serif;
        }
        body{
            background-color:#e9f5db ;
        }

        header{
            z-index: 999;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 20px;
            transition: 0.5s ease;
        }
        
        header .brand{
            color: #e9f5db;
            font-size: 1.5em;
            font-weight: 700;
            text-decoration: none;
        }

        header .navigation{
            position: relative;
        }

        header .navigation .navigation-items a{
            position: relative;
            color: #fff;
            font-size: 1em;
            font-weight: 500;
            text-decoration: none;
            margin-left: 30px;
            transition: 0.3s ease;
        }

        header .navigation .navigation-items a:before{
            content: '';
            position: absolute;
            background: #fff;
            width: 0;
            height: 3px;
            bottom: 0;
            left: 0;
            transistion: 0.3s ease;
        }

        header .navigation .navigation-items a:hover:before{
            width: 100%;
        }

        section{
            padding: 100px 200px;
        }

        .case{
            position: relative;
            width: 100%;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            flex-direction: column;
            background: #000000;
        }

        .case:before{
            z-index: 777;
            content: '';
            position: absolute;
            background: rgba(64, 64, 64, 0.5);
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
        }

        .case video{
            z-index: 000;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .case .content{
            z-index: 888;
            color: #fff;
            width: 70%;
            margin-top: 50px;
            display: none;
        }
        .case .content h1{
            font-size: 2.5em;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 5px;
            line-height: 75px;
            margin-bottom: 40px;
        }

        .case .content h1 span{
            font-size: 1.2rem;
            font-weight: 600;

        }

        .case .content.active{
            display: block;
        }
        .case .content a{
            background: #93C572;
            margin-left: 30px;
            position: relative;
            padding: 15px 35px;
            color: black;
            display: center;
            font-size: 1.1em;
            font-weight: 500;
            text-decoration: none;
            border-radius: 2px;
        }
        .video-slide.active{
            clip-path: circle(150% at 0 50%);
            transition: 2s ease;
            transition-property: clip-path;
        }
        .container {
            width: 1450px;
            padding: 50px 50px;
            display: flex; 
            justify-content: space-between;
            gap: 1.5rem; 
            align-items: center;
            cursor: pointer;
        }
        
        .container-box {
            display: ruby-base-container;
            align-items: center;
            gap: 1.8rem;
            border: 1px solid #000000;
            border-radius: 20px;
            padding: 20px 15px;
            box-shadow: -11.729px -11.729px 32px rgb(255 255 255 / 15%);
            transition: all 0.4s ease;
        }
        
        .container-box:hover {
            transform: translateY(-15px);
        }
        
        .container img {
            width: 280px;
        }
        
        .container-text h4{
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .center-text{
            text-align: center;
            line-height: -5.2;
        }
        
        .center-text h5{
            color: var(--main-color);
            font-size: 16px;
            font-weight: 600;
            letter-spacing: 1px;
            margin-bottom: 20px;
        }
        .center-text h5{
            color: black;
            font-size: 45px;
            font-weight: 600;
            letter-spacing: 1px;
            margin-bottom: 20px;
        }
        
        .center-text h2{
            font-size: 40px;
            line-height: -5.2;
          }
          
          .contentt {
            width: 1450px;
            padding: 12px 270px;
            display: flex; 
            justify-content: space-between;
            gap: 1.5rem; 
            align-items: center;
            cursor: pointer;
          }
          .categories-content {
            display: ruby-base-container;
            align-items: center;
            gap: 1.8rem;
            border: 1px solid #000000;
            border-radius: 20px;
            padding: 20px 15px;
            box-shadow: -11.729px -11.729px 32px rgb(255 255 255 / 15%);
            transition: all 0.4s ease;
          }
          
          .categories-content:hover {
            transform: translateY(-15px);
          }
          
          .box img {
            width: 280px;
          } 
            
          .main-btn{
            text-align: center;
            margin-top: 5rem;
          }

          .btn{
            display: inline-block;
            padding: 16px 30px;
            font-size: 25px;
            font-weight: 700;
            background-color: #b6c99a;
            color:black;
            border-radius: 30px;
            transition: all .40s ease;
          }

          .btn:hover{
            transform: scale(0.9) translateY(-5px);
          }

          .contenttt {
            width: 1150px;
            padding: 75px 10px;
            display: flex; 
            justify-content: space-between;
            gap: 1.5rem; 
            align-items: center;
            cursor: pointer;
          }
          .courses-content{
            display: ruby-base-container;
            align-items: center;
            gap: 1.8rem;
            padding: 20px 15px;
            transition: all 0.4s ease;
          }
          .courses-content:hover {
            transform: translateY(-15px);
          }

          .row{
            padding: 0px 0px 10px 0px;
            border-radius: 20px;
            box-shadow: 0px 5px 40px rgb(19 8 73 / 13%);
            transition: all .40s ease;
          }

          .row:hover{
            transform: translateY(-15px);
          }

          .row img{
            width: 100%;
            height: 320px;
            object-fit: cover;
            border-radius: 15px 15px 0px 0px;
          }
          .courses-text{
            padding: 35px 20px;
          }

          .courses-text h5{
            color:black;
            font-size: 18px;
            font-weight: 700;
          }

          .courses-text h3{
            font-size: 24px;
            font-weight: 700;
            line-height: 34px;
            margin: 15px 0 15px;
            transition: all .40s ease;
          }
          
          .courses-text:hover{
            color: orange;
          }
          .courses-text h6{
            color: #97a97c;
            font-size: 20px;
            float: 400;
            line-height: 30px;
            letter-spacing: 1px;
            margin-bottom: 30px;
          }

          .rating{
            display:flex;
            align-items: center;
            flex-wrap: wrap;
            justify-content: space-between;
          }
          .conten {
            width: 1150px;
            padding: 75px 170px;
            display: flex; 
            justify-content: space-between;
            gap: 1.5rem; 
            align-items: center;
            cursor: pointer;
          }

          .cta {
            display: ruby-base-container;
            align-items: center;
            gap: 1.8rem;
            padding: 20px 15px;
            transition: all 0.4s ease;
          }
          
          .cta img {
            width: 330px;
            cursor: pointer;
          }

          .about{
            background-position: center;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 2rem;
            align-items: center;
        }

        .about video{
            width: 750px;
        }
         
        .about-text h2{
            font-size: 50px;
            line-height: 1.2;
            margin-bottom: 20px;
        }
         
        .about-text p{
            font-size: 15px;
            color: #000000;
            font-weight: 500;
            line-height: 30px;
            margin-bottom: 30px;
        }
        .contact{
            width: 1450px;
            padding: 75px 170px;
        }
        .main-contact {
            display: flex;
            flex-direction: row;
            justify-content: flex-start;
            align-items: flex-start;
            flex-wrap: nowrap; 
            gap:10px -15px;
            max-width: 1200px;
            margin: 0px auto;
        }
        
        .contact-content {
            list-style: none;
            padding: 20px;
            margin: 0;
            flex: 1;
        }
        
        .contact-content img {
            width: 490px; 
            height: auto;
            padding-right: 230px ;
            margin-bottom: 10px;
        }
        
        .contact-content li {
            margin-bottom: 15px;
        }
        
        .contact-content li a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
        }
        
        .contact-content li a:hover {
            color: #007bff;
        }
        
        .contact-content li:last-child {
            margin-bottom: 0;
        }
        
          
        @media (max-width: 1040px){
            header{
                padding: 10px 3%;
                transition: .2s;
            }

        section{
            padding: 12px 20px;
        }

        header .navigation{
           display: none;
        }

        header .navigation.active{
            position: fixed;
            width: 100%;
            height: 100vh;
            top: 0;
            left: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background: rgba(1,1,1,0.5);
        }

        header .navigation .navigation-items a{
            color: #222;
            font-size: 1.2em;
            margin: 20px;
        }

        header .navigation .navigation-items a:before{
            background: #222;
            height: 5px;
        }

        header .navigation.active .navigation-items {
            background: #fff;
            width: 600px;
            max-width: 600px;
            margin: 20px;
            padding: 40px;
            display: flex;
            flex-direction: column;
            align-items: center;
            border-radius: 5px;
            box-shadow: 0 5px 25px rgb(1 1 1 / 20%);
        }

        .menu-btn{
            background: url(assets/imgs/Hlogo.jpg)no-repeat;
            background-size: 30px;
            background-position: center;
            width: 40px;
            height: 40px;
            cursor: pointer;
            transition: 0.3s ease;
        }

        .menu-btn.active{
            z-index: 999;
            background: url(assets/imgs/Hlogo.jpg)no-repeat;
            background-size: 25px;
            background-position: center;
            transition: 0.3s ease;
        }
    }
    
    </style>
    <body>
        <header>
            <a href="assets/imgs/we.jpg" class="brand">&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;AARAMB<br><small>- Where Ideas Meet -</small></a>
            <div class="menu-btn"></div>
            <div class="navigation">
                <div class="navigation-items">
                    <a href="index.php">HOME</a>
                    <a href="profile.php">PROFILE</a>
                    <a href="about.html">ABOUT</a>
                    <a href="contact.html">CONTACT US</a>
                    <a href="login.php">SIGN OUT</a>
                </div>
            </div>
        </header>
        <section class="case">
            <video class="video-slide-active" src="assets/imgs/index.mp4" autoplay muted loop></video>
            <div class="content active">
                <h1>Empowering Voices <br> Elevating Futures</h1>
            </div>
        </section>
        <section class="container">
            <div class="container-box">
                <div class="container-img">
                <a href="event.html"> <img src="assets/imgs/events.jpg"></a>
                </div>
                <div class="container-text">
                    <h4>EVENTS</h4>
                    <p>S I T A M</p>
                </div>
            </div>
            <div class="container-box">
                <div class="container-img">
                    <a href="sem.html"><img src="assets/imgs/seminars.jpg"></a>
                </div>
                <div class="container-text">
                    <h4>SEMINARS</h4>
                    <p>S I T A M</p>
                </div>
            </div>
            <div class="container-box">
                <div class="container-img">
                    <a href="web.html"><img src="assets/imgs/webinars.jpg"></a>
                </div>
                <div class="container-text">
                    <h4>WEBINARS</h4>
                    <p>S I T A M</p>
                </div>
            </div>
            <div class="container-box">
                <div class="container-img">
                    <a href="workshop.html"> <img src="assets/imgs/workshops.jpg"></a>
                </div>
                <div class="container-text">
                    <h4>WORKSHOPS</h4>
                    <p>S I T A M</p>
                </div>
            </div>
        </section>
        <section class="categories" id="categories">
            <div class="center-text">
                <h2>POPULAR CATEGORIES</h2>
            </div>
          </section>
          
            <section class="contentt">
                <div class="categories-content">
                <div class="box">
                <a href="ncc.html"><img src="assets/imgs/ncc.jpg"></a>
                    <h3>NCC</h3>
                    <p>S I T A M</p>
                </div>
            </div>
                <div class="categories-content">
                <div class="box">
                <a href="nss.html"><img src="assets/imgs/nss.jpg"></a>
                    <h3>NSS</h3>
                    <p>S I T A M</p>
                </div>
            </div>
                <div class="categories-content">
                <div class="box">
                <a href="idea.html"><img src="assets/imgs/idea.jpg"></a>
                    <h3>PLACE YOUR IDEA</h3>
                    <p>S I T A M</p>
                </div>
            </div>
            </section>
            </section>
            <br>
            <br>
            <br>
            <br>
            <section class="about" id="about">
                <div class="">
                    <img src="assets/imgs/blog.jpg">
                </div>
                <div class="about-text">
                    <h2>OUR BLOG'S</h2>
                    <p>blog is a dedicated space where students, faculty, and staff can share their experiences and knowledge gained from various academic conferences. These conferences often focus on specialized topics, ranging from cutting-edge research in science and technology to discussions on social issues, arts, and humanities.</p>
                    <a href="blog.html" class="btn">READ MORE</a>
                </div>
            </section>
            <section class="courses" id="courses">
                <div class="center-text">
                    <h2>Let's Connect</h2>
                </div>
                <section class="contenttt">
                <div class="courses-content">
                   <div class="row">
                    <a href="ccat.html"><img src="assets/imgs/team.jpg"></a>
                    <div class="courses-text">
                        <h3>Build Your Conversation</h3>
                        <h6>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;S I T A M</h6>
                    </div>
                   </div> 
                </div>
                <div class="courses-content">
                    <div class="row">
                    <a href="commitee.html"><img src="assets/imgs/committee.jpg"></a>
                     <div class="courses-text">
                         <h3>Committee Member's&ensp;&ensp;</h3>
                         <h6>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;S I T A M</h6>
                     </div>
                    </div> 
                 </div>
                 <div class="courses-content">
                    <div class="row">
                    <a href="faqs.html"><img src="assets/imgs/faq.jpg"></a>
                     <div class="courses-text">
                         <h3>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;FAQ'S&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;</h3>
                         <h6>&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;S I T A M</h6>
                     </div>
                    </div> 
                 </div>
            </section>
        </section>
        <section class="cta">
            <div class="center-text">
                <h5>Placements Record</h5>
                <h2>500+ Global Corporates from 2022 to 2025</h2>
            </div>
            <section class="conten">
            <div class="cta-content">
                <div class="">
                    <img src="assets/imgs/brand.jpg">
                </div>
            </div>
            <div class="cta-content">
                <div class="">
                    <img src="assets/imgs/brand2.jpg">
                </div>
            </div>
            <div class="cta-content">
                <div class="">
                    <img src="assets/imgs/brand3.jpg">
                </div>
            </div>
        </section>
    </section>
    <section class="about" id="about">
        <div class="">
            <video class="video" src="assets/imgs/sitam.mp4" autoplay muted loop></video>
        </div>
        <div class="about-text">
            <h2>S I T A M</h2>
            <p>Our college is an institution of higher education that serves as a pivotal place for intellectual growth, personal development, and professional preparation. Colleges offer a variety of programs, ranging from undergraduate to postgraduate degrees, across multiple disciplines such as arts, sciences, engineering, business, and humanities.</p>
            <a href="sitam.html" class="btn">READ MORE</a>
        </div>
    </section>
    <P>____________________________________________________________________________________________________________________________________________________________________</P>
        <section class="contact" id="contact">
            <div class="main-contact">
                <div class="contact-content">
                    <img src="assets/imgs/logo.jpg">
                </div>
                <div class="contact-content">
                    <li><a href="#" >Home</a></li>
                    <li><a href="#categories" >Categories</a></li>
                    <li><a href="#courses" >Let's Connect</a></li>
                    <li><a href="#about" >Our Blog</a></li>
                </div>
                <div class="contact-content">
                    <li><a href="profile.php" >Profile</a></li>
                    <li><a href="#" >Dashboard</a></li>
                </div>
                <div class="contact-content">
                    <li><a href="#" >Gajularega <br> Vizianagaram <br> India</a></li>
                    <li><a href="#" >sitam@gmail.com</a></li>
                    <li><a href="#" >0415234233329</a></li>
            </div>
        </section>
        <script type="text/javascript" src="js/script.js"></script>
    </body>
</html>