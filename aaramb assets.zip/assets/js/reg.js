function validation() {
    console.log("Validation function called");

    if (document.Formfill.CollegeName.value === "") {
        document.getElementById("result").innerHTML = "Enter CollegeName*";
        return false;
    }
    if (document.Formfill.CollegeCode.value === "") {
        document.getElementById("result").innerHTML = "Enter CollegeCode*";
        return false;
    }
    if (document.Formfill.Email.value === "") {
        document.getElementById("result").innerHTML = "Enter your Email*";
        return false;
    }
    if (document.Formfill.Location.value === "") {
        document.getElementById("result").innerHTML = "Enter Location*";
        return false;
    }
    if (document.Formfill.Location.value.length < 6) {
        document.getElementById("result").innerHTML = "Location must be at least 6 characters";
        return false;
    }

    // Clear previous messages
    document.getElementById("result").innerHTML = "";
    console.log("Validation passed, showing popup");

    // Show success popup
    document.getElementById("popup").style.display = "block";
    return false; // Prevent form submission to show popup
}
